<div class="logo">
    <img class="logo_img" src="<?php echo e(asset($site_logo)); ?>" alt="logo">
</div><?php /**PATH C:\laragon\www\elnawader\resources\views/components/logo-component.blade.php ENDPATH**/ ?>