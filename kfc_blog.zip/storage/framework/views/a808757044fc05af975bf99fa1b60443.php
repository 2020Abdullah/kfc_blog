

<?php $__env->startSection('page-title'); ?>
<?php echo e($page->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-social'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta property="og:title" content="<?php echo e($page->title); ?>" />
<meta property="og:description" content="<?php echo e(Str::limit(strip_tags($page->content), 150)); ?>" />
<meta property="og:image" content="<?php echo e(asset($page->main_image)); ?>" />
<meta property="og:url" content="<?php echo e(request()->url()); ?>" />
<meta property="og:type" content="article" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section id="kfc_post">
    <div class="heading_wrapper">
        <div class="container">
            <div class="heading_section">
                <h3><?php echo e($page->title); ?></h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item" aria-current="page">الرئيسية</li>
                      <li class="breadcrumb-item active" aria-current="page"><?php echo e($page->title); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <!-- post view -->
            <div class="col-md-8">
                <div class="post-wrapper">
                    <div class="card">
                        <div class="card-image">
                            <img src="<?php echo e(asset($page->main_image)); ?>" alt="<?php echo e($page->title); ?>">
                        </div>
                        <div class="card-body post_view">
                            <div class="post-header">
                                <h3 class="post-heading"><?php echo e($page->title); ?></h3>
                                <div class="post-meta">
                                    <span id="hijri-date">تاريخ النشر : <?php echo e($hijriDate); ?></span>
                                </div>
                                <div class="post-content">
                                    <?php echo $page->content; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- sidebar -->
            <div class="col-md-4">
                <div class="sidebar-wrapper">
                    <!-- nav links pages -->
                    <div class="card">
                        <div class="card-header">
                            <h3>الصفحات</h3>
                        </div>
                        <div class="card-body">
                            <div class="list-group list-group-flush">
                                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <a class="link" href="<?php echo e(route('pageView', ['id' => $page->id, 'slug' => Str::slug($page->title)])); ?>" class="mx-2"><?php echo e($page->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
function printSpecificContent(className) {
    let printContents = document.querySelector(className).innerHTML;
    let originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents; // استبدال محتوى الصفحة بالمحتوى المطلوب طباعته
    window.print(); // تشغيل الطباعة
    document.body.innerHTML = originalContents; // إعادة المحتوى الأصلي بعد الطباعة
}
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kfc_blog\resources\views/fronted/page.blade.php ENDPATH**/ ?>