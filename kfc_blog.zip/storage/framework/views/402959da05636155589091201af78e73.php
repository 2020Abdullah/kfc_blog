<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="rtl">
<head>
    <!-- meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0,minimal-ui">
    <meta name="description" content="Vuexy admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, Vuexy admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- title page -->
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;500;600;700;800;900;1000&display=swap" rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/vendors/css/vendors-rtl.min.css')); ?>">
    <!-- END: Vendor CSS-->

    
    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/all.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/bootstrap-extended.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/colors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/components.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/themes/dark-layout.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/themes/bordered-layout.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/themes/semi-dark-layout.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/core/menu/menu-types/vertical-menu.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/custom-rtl.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css-rtl/mystyle.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body class="vertical-layout vertical-menu-modern  navbar-floating footer-static" data-open="click" data-menu="vertical-menu-modern" data-col="">
    <div id="app">
        <?php if (isset($component)) { $__componentOriginal82af475b2f189e22900dd8a90e224552 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal82af475b2f189e22900dd8a90e224552 = $attributes; } ?>
<?php $component = App\View\Components\HeaderDashboard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('header-dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HeaderDashboard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal82af475b2f189e22900dd8a90e224552)): ?>
<?php $attributes = $__attributesOriginal82af475b2f189e22900dd8a90e224552; ?>
<?php unset($__attributesOriginal82af475b2f189e22900dd8a90e224552); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal82af475b2f189e22900dd8a90e224552)): ?>
<?php $component = $__componentOriginal82af475b2f189e22900dd8a90e224552; ?>
<?php unset($__componentOriginal82af475b2f189e22900dd8a90e224552); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal8dd8b461b31e0f9376d40ea893d997e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8dd8b461b31e0f9376d40ea893d997e7 = $attributes; } ?>
<?php $component = App\View\Components\SidebarDashboard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar-dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\SidebarDashboard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8dd8b461b31e0f9376d40ea893d997e7)): ?>
<?php $attributes = $__attributesOriginal8dd8b461b31e0f9376d40ea893d997e7; ?>
<?php unset($__attributesOriginal8dd8b461b31e0f9376d40ea893d997e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8dd8b461b31e0f9376d40ea893d997e7)): ?>
<?php $component = $__componentOriginal8dd8b461b31e0f9376d40ea893d997e7; ?>
<?php unset($__componentOriginal8dd8b461b31e0f9376d40ea893d997e7); ?>
<?php endif; ?>
        <!-- content -->
        <div class="app-content content">
            <div class="content-overlay"></div>
            <div class="header-navbar-shadow"></div>
            <div class="content-wrapper container-xxl p-0">
                <div class="content-header row">
                    <?php echo $__env->yieldContent('page-title'); ?>
                </div>
                <?php echo $__env->yieldContent('page-header'); ?>
                <div class="content-body">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Scripts -->
    <script src="<?php echo e(asset('backend/vendors/js/vendors.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/core/app.js')); ?>"></script>
    <script>

        // add active url to page target
        var Currentpath = $(location).attr("pathname");
        
        $(".navigation .nav-item").each(function(index, item){
            if($(this).find('a').attr('href').indexOf(Currentpath) !== -1){
                $(".navigation .nav-item").removeClass('active');
                $(this).addClass('active');
            }
        })

        $(window).on('load', function() {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        })
    </script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    
    <?php echo $__env->make('sweetalert::alert', ['cdn' => "https://cdn.jsdelivr.net/npm/sweetalert2@9"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('js'); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\kfc_blog\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>