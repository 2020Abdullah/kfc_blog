

<?php $__env->startSection('page-header'); ?>
<div class="content-header row">
    <div class="content-header-left col-md-9 col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h2 class="content-header-title float-start mb-0"><?php echo e($page->title); ?></h2>
                <div class="breadcrumb-wrapper">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">الرئيسية</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#"><?php echo e($page->title); ?></a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content-header-right text-md-end col-md-3 col-12">
        <div class="mb-1 breadcrumb-right">
            <a href="<?php echo e(route('page.view')); ?>" class="btn btn-primary waves-effect waves-float waves-light">عودة للصفحات</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="blogView">
        <!-- show blog -->
        <div class="blog-wrapper">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="card shadow">
                        <div class="card-image">
                            <img src="<?php echo e(asset($page->main_image)); ?>" alt="<?php echo e($page->title); ?>">
                        </div>
                        <div class="card-body">
                            <h3 class="card-title text-center"><?php echo e($page->title); ?></h3>
                            <p class="text-muted text-center">نشر في <?php echo e($page->created_at->format('d M Y')); ?></p>

                            
                            <div class="article-content">
                                <?php echo $page->content; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kfc_blog\resources\views/dashboard/page/show.blade.php ENDPATH**/ ?>