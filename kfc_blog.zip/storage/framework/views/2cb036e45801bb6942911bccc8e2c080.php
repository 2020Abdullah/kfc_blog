

<?php $__env->startSection('content'); ?>
    <section id="category">
        <!-- validation -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <h3 class="alert-heading">حدث خطأ ما</h3>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="alert-body">
                        <?php echo e($error); ?>

                   </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <!-- show success message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <h3 class="alert-heading">عملية ناجحة</h3>
                <div class="alert-body">
                    <?php echo e(session('success')); ?>

                </div>
            </div>
        <?php endif; ?>

        <!-- show table -->
        <div class="card">  
            <div class="card-header">
                <h3>أقسام الموقع</h3>
                <div class="table-action">
                    <button class="btn btn-primary waves-effect waves-float waves-light" data-bs-toggle="modal" data-bs-target="#createModel">أضف قسم جديد</button>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>رقم القسم</th>
                                <th>اسم القسم</th>
                                <th>الحالة</th>
                                <th>إجراء</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $Allcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($cate->name); ?></td>
                                    <td>
                                        <?php if($cate->statue === 1): ?>
                                            <span class="badge rounded-pill badge-light-primary me-1">مفعل</span>
                                        <?php else: ?> 
                                            <span class="badge rounded-pill badge-light-danger me-1">غير مفعل</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-sm dropdown-toggle hide-arrow py-0 waves-effect waves-float waves-light" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i data-feather="more-vertical"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a class="dropdown-item editBtn" href="#" data-id="<?php echo e($cate->id); ?>" data-name="<?php echo e($cate->name); ?>" data-bs-toggle="modal" data-bs-target="#UpdateModel"> 
                                                    <i data-feather="edit-2" class="me-50"></i>
                                                    <span>تعديل</span>
                                                </a>
                                                <a class="dropdown-item delBtn" href="#" data-id="<?php echo e($cate->id); ?>" data-bs-toggle="modal" data-bs-target="#DelModel">
                                                    <i data-feather="trash" class="me-50"></i>
                                                    <span>حذف</span>
                                                </a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="text-center">
                                    <td colspan="4">لا توجد اى اقسام مضافة</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <!-- models action -->
        <?php echo $__env->make('dashboard.category.models', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(".editBtn").on('click', function(){
        let cate_id = $(this).attr('data-id')
        let cate_name = $(this).attr('data-name')

        $("#UpdateModel .id").val(cate_id);
        $("#UpdateModel .name").val(cate_name);
    })

    $(".delBtn").on('click', function(){
        let cate_id = $(this).attr('data-id')

        $("#DelModel .cate_id").val(cate_id);
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elnawader\resources\views/dashboard/category/index.blade.php ENDPATH**/ ?>