

<?php $__env->startSection('content'); ?>
    <section id="dashboard">
        تهانينا لقد وصلت إلي النهاية !
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elnawader\resources\views/dashboard/home.blade.php ENDPATH**/ ?>