<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo $__env->yieldContent('page-title'); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@100..900&display=swap" rel="stylesheet">
        
        <!-- swiper library js -->
        <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"
        />

        <!-- fontasome  -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <!-- bootstrap -->
        <link rel="stylesheet" href="<?php echo e(asset('fronted/css/bootstrap.rtl.min.css')); ?>" />

        <!-- mystyle -->
        <link rel="stylesheet" href="<?php echo e(asset('fronted/css/style.css')); ?>" />

    </head>
    <body>
        <!-- header section -->
        <?php if (isset($component)) { $__componentOriginalff17a25da2dfdb93382574c3fb700555 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff17a25da2dfdb93382574c3fb700555 = $attributes; } ?>
<?php $component = App\View\Components\HeaderSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Header-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HeaderSection::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff17a25da2dfdb93382574c3fb700555)): ?>
<?php $attributes = $__attributesOriginalff17a25da2dfdb93382574c3fb700555; ?>
<?php unset($__attributesOriginalff17a25da2dfdb93382574c3fb700555); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff17a25da2dfdb93382574c3fb700555)): ?>
<?php $component = $__componentOriginalff17a25da2dfdb93382574c3fb700555; ?>
<?php unset($__componentOriginalff17a25da2dfdb93382574c3fb700555); ?>
<?php endif; ?>

        <!-- content section -->
        <?php echo $__env->yieldContent('content'); ?>

        <!-- footer section -->
        <?php if (isset($component)) { $__componentOriginale57bd5996d831aab5c0ee29f0b6f830f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale57bd5996d831aab5c0ee29f0b6f830f = $attributes; } ?>
<?php $component = App\View\Components\FooterSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('Footer-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FooterSection::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale57bd5996d831aab5c0ee29f0b6f830f)): ?>
<?php $attributes = $__attributesOriginale57bd5996d831aab5c0ee29f0b6f830f; ?>
<?php unset($__attributesOriginale57bd5996d831aab5c0ee29f0b6f830f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale57bd5996d831aab5c0ee29f0b6f830f)): ?>
<?php $component = $__componentOriginale57bd5996d831aab5c0ee29f0b6f830f; ?>
<?php unset($__componentOriginale57bd5996d831aab5c0ee29f0b6f830f); ?>
<?php endif; ?>
        
        <!-- All scripts -->
        <script src="<?php echo e(asset('fronted/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
        <script src="<?php echo e(asset('fronted/js/scripts.js')); ?>"></script>
        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\elnawader\resources\views/layouts/guest.blade.php ENDPATH**/ ?>