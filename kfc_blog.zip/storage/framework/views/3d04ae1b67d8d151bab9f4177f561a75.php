 <!-- header Top -->
 <header class="top-header">
  <nav class="nav nav-pages">
    <?php $__currentLoopData = $headerLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="nav-item"><a class="nav-link" href="<?php echo e(route('pageView', ['id' => $link->id, 'slug' => Str::slug($link->title)])); ?>" class="mx-2"><?php echo e($link->title); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </nav>
  <div class="dateToday">
      <span><?php echo e($hijriDate); ?></span>
  </div>
  <div class="header_pages_left">
      <a href="#" class="btn btn-outline btn-sm mx-2">EN</a>
      <a class="link" href="<?php echo e(route('login')); ?>">
        <i class="fa fa-user"></i>
      </a>
  </div>
</header>

<!-- main header -->
<nav class="main_nav navbar navbar-expand-lg">
  <div class="container">
    <div class="menu_wrapper">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
          <?php if (isset($component)) { $__componentOriginalb2122d5063402898d1708e1090474179 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2122d5063402898d1708e1090474179 = $attributes; } ?>
<?php $component = App\View\Components\LogoComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LogoComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2122d5063402898d1708e1090474179)): ?>
<?php $attributes = $__attributesOriginalb2122d5063402898d1708e1090474179; ?>
<?php unset($__attributesOriginalb2122d5063402898d1708e1090474179); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2122d5063402898d1708e1090474179)): ?>
<?php $component = $__componentOriginalb2122d5063402898d1708e1090474179; ?>
<?php unset($__componentOriginalb2122d5063402898d1708e1090474179); ?>
<?php endif; ?>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" href="#mobileMenu" role="button" aria-controls="offcanvasExample">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- desktop menu -->
        <div class="main_menu_links">
            <ul class="nav navbar-nav">
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                  <?php if($cate->blogs->count() > 0): ?>
                    <a class="nav-link toggle-menu" href="#"><?php echo e($cate->name); ?></a>
                    <div class="mega-menu">
                        <div class="row">
                                <?php $__currentLoopData = $cate->blogs->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                      <div class="mega-item">
                                        <ul>
                                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('blogView', ['id' => $blog->id, 'slug' => Str::slug($blog->title)])); ?>"><?php echo e($blog->title); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                      </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                  <?php else: ?> 
                    <a class="nav-link" href="#"><?php echo e($cate->name); ?></a>
                  <?php endif; ?>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="nav navbar accessibility_icons">
            <div class="dropdown">
              <button class="btn btn-icon" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fa fa-search"></i>
              </button>
              <ul class="dropdown-menu asset_menu_mega">
                <li>
                  <a class="dropdown-item" href="#">
                    <div class="asset_icon_mega">
                      <div class="serach-box">
                          <div class="card">
                              <div class="card-body">
                                  <h4>البحث</h4>
                                  <form action="<?php echo e(route('search')); ?>" method="GET">
                                      <?php echo csrf_field(); ?>
                                      <input type="search" name="query" class="form-control search-input" placeholder="عنوان الخبر أو المحتوى">
                                      <button type="submit" class="btn btn-primary">بحث</button>
                                  </form>
                              </div>
                          </div>
                      </div>
                    </div>
                  </a>
                </li>
              </ul>
            </div>

        </div>
        <!-- end desktop menu -->

        <!-- mobile menu -->
        <div class="offcanvas offcanvas-start d-lg-none" tabindex="-1" id="mobileMenu" aria-labelledby="mobileMenuLabel">
          <div class="offcanvas-header">
            <h5 class="offcanvas-title headerTop">
              <div class="dateToday">
                  <span><?php echo e($hijriDate); ?></span>
              </div>
            </h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>
          <div class="offcanvas-body">
            <nav class="nav nav-pages">
              <?php $__currentLoopData = $headerLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('pageView', ['id' => $link->id, 'slug' => Str::slug($link->title)])); ?>" class="mx-2"><?php echo e($link->title); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
            <hr />
            <div class="nav accessibility_icons">
              <div class="dropdown">
                <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <i class="fa fa-search"></i>
                </button>
                <ul class="dropdown-menu">
                  <div class="serach-box">
                      <div class="card">
                          <div class="card-body">
                              <h4>البحث</h4>
                              <form action="<?php echo e(route('search')); ?>" method="GET">
                                  <?php echo csrf_field(); ?>
                                  <input type="search" name="query" class="form-control search-input" placeholder="عنوان الخبر أو المحتوى">
                                  <button type="submit" class="btn btn-primary">بحث</button>
                              </form>
                          </div>
                      </div>
                  </div>
                </ul>
              </div>

              

            </div>
            <hr />
            <ul class="nav navbar-nav">
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                  <?php if($cate->blogs->count() > 0): ?>
                    <a class="nav-link toggle-menu" href="#"><?php echo e($cate->name); ?></a>
                    <div class="mega-menu">
                        <div class="row">
                                <?php $__currentLoopData = $cate->blogs->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                      <div class="mega-item">
                                        <ul>
                                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="#"><?php echo e($blog->title); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                      </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                  <?php else: ?> 
                    <a class="nav-link" href="#"><?php echo e($cate->name); ?></a>
                  <?php endif; ?>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
    </div>
  </div>
</nav>
<?php /**PATH C:\laragon\www\kfc_blog\resources\views/components/header-section.blade.php ENDPATH**/ ?>