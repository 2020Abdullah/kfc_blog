

<?php $__env->startSection('page-title'); ?>
المصور التركي التويجرى
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section id="elnawader_hero" style="background-image: url(<?php echo e(asset($siteInfo->site_cover)); ?>)">
    <div class="hero_wrapper">
        <h3><?php echo e($siteInfo->welcome_txt); ?></h3>
    </div>
</section>

<section id="elnawader_category">
    <div class="container">
        <h3 class="heading_category">أقسام الموقع</h3>
        <nav class="nav">
            <a class="nav-link active" aria-current="page" href="#">الرئيسية</a>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('categoryView', $cate->id)); ?>"><?php echo e($cate->name); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
    </div>
</section>

<section id="elnawader_slider">
    <div class="container">
        <!-- Slider main container -->
        <div class="swiper">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
              <!-- Slides -->
              <?php $__currentLoopData = $sliderImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <img src="<?php echo e(asset('uploads/slider/' . $image->image_path)); ?>" alt="img" />
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>          
        </div>
    </div>
</section>

<section id="elnawader_wedding">
    <div class="container">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3 class="heading">
                <a class="link" href="<?php echo e(route('categoryView', $cate->id)); ?>">
                    <?php echo e($cate->name); ?> اضغط هنا
                </a>
            </h3>
            <div class="elnawader_box">
                <div class="row">
                    <?php $__currentLoopData = $getBlogLast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($blog->category_id === $cate->id): ?>
                            <div class="col-md-4">
                                <div class="card">
                                    <a href="<?php echo e(route('blogView', $blog->id)); ?>">
                                        <div class="card-image">
                                            <img src="<?php echo e(asset($blog->main_image)); ?>" alt="<?php echo e($blog->title); ?>">
                                        </div>
                                    </a>
                                    <div class="card-body">
                                        <a class="link" href="<?php echo e(route('blogView', $blog->id)); ?>">
                                            <h3><?php echo e($blog->title); ?></h3>
                                        </a>
                                    </div>
                                    <div class="card-footer">
                                        <span><?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d/m/Y')); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
let swiper = new Swiper(".swiper", {
    loop: true,
    slidesPerView: 1, // الافتراضي للموبايل
    spaceBetween: 10, // المسافة بين الصور
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    breakpoints: {
        768: { // الأجهزة المتوسطة (التابلت)
            slidesPerView: 2,
            spaceBetween: 20
        },
        1024: { // الأجهزة الكبيرة (الكمبيوتر)
            slidesPerView: 3,
            spaceBetween: 30
        }
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elnawader\resources\views/fronted/home.blade.php ENDPATH**/ ?>