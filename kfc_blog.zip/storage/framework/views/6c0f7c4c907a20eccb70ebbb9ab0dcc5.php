

<?php $__env->startSection('page-title'); ?>
<?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-social'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta property="og:title" content="<?php echo e($post->title); ?>" />
<meta property="og:description" content="<?php echo e(Str::limit(strip_tags($post->content), 150)); ?>" />
<meta property="og:image" content="<?php echo e(asset($post->main_image)); ?>" />
<meta property="og:url" content="<?php echo e(request()->url()); ?>" />
<meta property="og:type" content="article" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section id="kfc_post">
    <div class="heading_wrapper">
        <div class="container">
            <div class="heading_section">
                <h3>التفاصيل</h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item" aria-current="page">الرئيسية</li>
                      <li class="breadcrumb-item active" aria-current="page"><?php echo e($post->title); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <!-- post view -->
            <div class="col-md-8">
                <div class="post-wrapper">
                    <div class="card">
                        <div class="card-image">
                            <img src="<?php echo e(asset($post->main_image)); ?>" alt="<?php echo e($post->title); ?>">
                        </div>
                        <div class="card-body post_view">
                            <div class="post-header">
                                <h3 class="post-heading"><?php echo e($post->title); ?></h3>
                                <div class="post-meta">
                                    <button onclick="printSpecificContent('.post_view')" class="print-btn">طباعة الخبر</button>
                                    <span id="hijri-date">تاريخ النشر : <?php echo e($hijriDate); ?></span>
                                </div>
                                <div class="post-content">
                                    <?php echo $post->content; ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if($nextArticle): ?>
                        <div class="post_Next">
                            <div class="section-heading">
                                <h3>تابع القراءة </h3>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                    <a href="#" class="post_box_right">
                                        <div class="card-image">
                                            <img src="<?php echo e(asset($nextArticle->main_image)); ?>" alt="<?php echo e($nextArticle->title); ?>">
                                        </div>
                                        <div class="post_meta">
                                            <h4 class="news_repeater_title"><?php echo e($nextArticle->title); ?></h4>
                                            <span class="news_repeater_date"> <?php echo e(\Carbon\Carbon::parse($nextArticle->created_at)->format('Y/m/d')); ?></span>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="News_latest">
                        <div class="section-heading">
                            <h3>أحدث الأخبار</h3>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $latestArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <div class="card post_card">
                                        <div class="card-body">
                                            <div class="card-image">
                                                <img src="<?php echo e(asset($art->main_image)); ?>" alt="<?php echo e($art->title); ?>">
                                            </div>

                                            <h3 class="post_title">
                                                <a href="<?php echo e(route('blog.show', ['id' => $art->id, 'slug' => Str::slug($art->title)])); ?>"><?php echo e($art->title); ?></a>
                                            </h3>
                                
                                            <p class="post_info"><?php echo Str::limit($art->content, 100); ?></p>
                                            <a class="Readmore" href="<?php echo e(route('blog.show', ['id' => $art->id, 'slug' => Str::slug($art->title)])); ?>" class="text-green-600 font-semibold mt-3 block">إقرأ المزيد</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="allNews">
                            <a href="<?php echo e(route('allNews')); ?>" class="btn btn-primary">
                                المزيد من الأخبار
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- sidebar -->
            <div class="col-md-4">
                <div class="sidebar-wrapper">
                    <div class="card">
                        <div class="card-body">
                            <div class="serach-box">
                                <h4>البحث</h4>
                                <form action="<?php echo e(route('search')); ?>" method="GET">
                                    <?php echo csrf_field(); ?>
                                    <input type="search" name="query" class="form-control search-input" placeholder="عنوان الخبر أو المحتوى">
                                    <button type="submit" class="btn btn-primary">بحث</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="share-box text-center">
                                <h4 class="share-title">نشر الخبر عن طريق</h4>
                                <hr>
                                <div class="social-icons">
                                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e(urlencode(request()->url())); ?>" target="_blank" class="linkedin">
                                        <i class="fab fa-linkedin-in"></i>
                                    </a>
                                    <a href="https://t.me/share/url?url=<?php echo e(urlencode(request()->url())); ?>" target="_blank" class="telegram">
                                        <i class="fab fa-telegram-plane"></i>
                                    </a>
                                    <a href="https://wa.me/?text=<?php echo e(urlencode(request()->url())); ?>" target="_blank" class="whatsapp">
                                        <i class="fab fa-whatsapp"></i>
                                    </a>
                                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(request()->url())); ?>" target="_blank" class="facebook">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                    <a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(request()->url())); ?>" target="_blank" class="twitter">
                                        <i class="fab fa-x-twitter"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="posts-box">
                                <h3>الملف الصحفي</h3>
                                <hr/>
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="#" class="post_news_paper">
                                        <div class="post_news_paper_head">
                                            <h3 class="post_news_paper_title">وكالة الأنباء السعودية</h3>
                                            <span class="post_news_paper_date"><?php echo e(\Carbon\Carbon::parse($article->created_at)->format('Y/m/d')); ?></span>
                                        </div>
                                        <p class="post_news_paper_info">
                                            <?php echo e(Str::limit($article->title, 60)); ?>

                                        </p>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
function printSpecificContent(className) {
    let printContents = document.querySelector(className).innerHTML;
    let originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents; // استبدال محتوى الصفحة بالمحتوى المطلوب طباعته
    window.print(); // تشغيل الطباعة
    document.body.innerHTML = originalContents; // إعادة المحتوى الأصلي بعد الطباعة
}
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kfc_blog\resources\views/fronted/post.blade.php ENDPATH**/ ?>