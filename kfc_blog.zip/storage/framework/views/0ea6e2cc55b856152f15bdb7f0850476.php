<div class="logo">
    <?php if($site_logo !== null): ?>
        <img class="logo_img" src="<?php echo e(asset($site_logo)); ?>" alt="logo">
    <?php else: ?> 
        <img src="<?php echo e(asset('fronted/img/KFU_logo_white.png')); ?>" alt="KFU Logo" height="50">
    <?php endif; ?>
</div><?php /**PATH C:\laragon\www\kfc_blog\resources\views/components/logo-component.blade.php ENDPATH**/ ?>