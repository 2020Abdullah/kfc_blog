

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/vendors/css/forms/wizard/bs-stepper.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css-rtl/plugins/forms/form-wizard.css')); ?>">
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<div class="content-header row">
    <div class="content-header-left col-md-9 col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h2 class="content-header-title float-start mb-0">إنشاء معرض</h2>
                <div class="breadcrumb-wrapper">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">الرئيسية</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#">إنشاء معرض</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="slider_view">
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <div class="alert-body">
                <?php echo e(session('message')); ?>

            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('slider-create');

$__html = app('livewire')->mount($__name, $__params, 'lw-2468730996-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kfc_blog\resources\views/dashboard/gellery/create.blade.php ENDPATH**/ ?>