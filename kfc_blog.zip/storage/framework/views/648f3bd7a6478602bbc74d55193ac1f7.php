<header class="elnawader_header">
  <nav class="navbar navbar-expand-lg">
      <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
          <?php if (isset($component)) { $__componentOriginalb2122d5063402898d1708e1090474179 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2122d5063402898d1708e1090474179 = $attributes; } ?>
<?php $component = App\View\Components\LogoComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LogoComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2122d5063402898d1708e1090474179)): ?>
<?php $attributes = $__attributesOriginalb2122d5063402898d1708e1090474179; ?>
<?php unset($__attributesOriginalb2122d5063402898d1708e1090474179); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2122d5063402898d1708e1090474179)): ?>
<?php $component = $__componentOriginalb2122d5063402898d1708e1090474179; ?>
<?php unset($__componentOriginalb2122d5063402898d1708e1090474179); ?>
<?php endif; ?>
        </a>

          <!-- search icon  -->
          

        <!-- mobile icon -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <i class="fa fa-bars"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">

          <!-- navs links  -->
          <ul class="navbar-nav">
              <li class="nav-item">
                  <a class="nav-link active" href="<?php echo e(url('/')); ?>">الرئيسية</a>
              </li>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('categoryView', $cate->id)); ?>"><?php echo e($cate->name); ?></a>
                </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>

          <!-- social-icons -->
          <div class="social-icons d-flex align-items-center">
              <a href="https://wa.me/<?php echo e($siteInfo->whatsUp_number); ?>"><i class="fab fa-whatsapp"></i></a>
              <a href="<?php echo e($siteInfo->snapchat_link); ?>"><i class="fab fa-snapchat"></i></a>
              <a href="<?php echo e($siteInfo->intagram_link); ?>"><i class="fab fa-instagram"></i></a>
          </div>
        </div>
      </div>
    </nav>
</header><?php /**PATH C:\laragon\www\elnawader\resources\views/components/header-section.blade.php ENDPATH**/ ?>