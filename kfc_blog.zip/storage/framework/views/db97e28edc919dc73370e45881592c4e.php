

<?php $__env->startSection('page-header'); ?>
<div class="content-header row">
    <div class="content-header-left col-md-9 col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h2 class="content-header-title float-start mb-0">المواضيع</h2>
                <div class="breadcrumb-wrapper">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">الرئيسية</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#">عرض المواضيع</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content-header-right text-md-end col-md-3 col-12">
        <div class="mb-1 breadcrumb-right">
            <a class="btn btn-primary waves-effect waves-float waves-light" href="<?php echo e(route('blog.add')); ?>">إضافة مقالة جديدة</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="blogView">
        <!-- show blog -->
        <div class="blog-list-wrapper">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-image">
                                <a href="<?php echo e(route('blog.show', $blog->id)); ?>">
                                    <img class="card-img-top" src="<?php echo e(asset($blog->main_image)); ?>" alt="<?php echo e($blog->title); ?>">
                                </a>
                            </div>
                            <div class="card-body">
                                
                                <h5 class="card-title"><?php echo e($blog->title); ?></h5>
                                
                                
                                <p class="card-text">
                                    <?php echo e(Str::limit(strip_tags($blog->content), 100)); ?>

                                </p>
                        
                                
                                <a href="<?php echo e(route('blog.show', $blog->id)); ?>" class="btn btn-primary">
                                    اقرأ المزيد
                                </a>

                                <a href="<?php echo e(route('blog.edit', $blog->id)); ?>" class="btn btn-success">
                                    تعديل المقال
                                </a>

                                <a href="<?php echo e(route('blog.show', $blog->id)); ?>" class="btn btn-danger delBtn" data-id="<?php echo e($blog->id); ?>" data-bs-toggle="modal" data-bs-target="#DelModel">
                                    حذف المقال
                                </a>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3>لا توجد اى مقالات مضافة</h3>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- model delete -->
    <?php echo $__env->make('dashboard.blog.Mdel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    $(".delBtn").on('click', function(){
        let blog_id = $(this).attr('data-id')
        $("#DelModel .blog_id").val(blog_id);
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elnawader\resources\views/dashboard/blog/index.blade.php ENDPATH**/ ?>