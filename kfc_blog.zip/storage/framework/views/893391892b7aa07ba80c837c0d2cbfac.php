<footer class="footer">
    <div class="footer-top">
      <div class="footer-column">
        <h3>تواصل معنا</h3>
        <p><?php echo e($siteInfo->phone_number); ?></p>
        <p><?php echo e($siteInfo->site_email); ?></p>
        <p><?php echo e($siteInfo->address); ?></p>
        <p>ص.ب 400 - الرمز البريدي <?php echo e($siteInfo->zip_code); ?></p>
      </div>
  
      <div class="footer-column">
        <h3>روابط تهمك</h3>
        <ul>
          <?php $__currentLoopData = $FooterLink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('pageView', ['id' => $link->id, 'slug' => Str::slug($link->title)])); ?>" class="mx-2"><?php echo e($link->title); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
  
      <div class="footer-column">
        <h3 class="head">حمل تطبيق جامعة الملك فيصل على الهواتف الذكية</h3>
        <div class="app-links">
          <a href="<?php echo e($siteInfo->google_play ? $siteInfo->google_play : '#'); ?>"><img src="<?php echo e(asset('assets/google-play.png')); ?>" alt="Google Play"></a>
          <a href="<?php echo e($siteInfo->app_store ?  $siteInfo->app_store : '#'); ?>"><img src="<?php echo e(asset('assets/app-store.png')); ?>" alt="App Store"></a>
        </div>
        <div class="social-links">
          <a href="<?php echo e($siteInfo->intagram_link ?  $siteInfo->intagram_link : '#'); ?>"><img src="<?php echo e(asset('assets/instagram.png')); ?>" alt="Instagram"></a>
          <a href="<?php echo e($siteInfo->youtube_link ?  $siteInfo->youtube_link : '#'); ?>"><img src="<?php echo e(asset('assets/youtube.png')); ?>" alt="YouTube"></a>
          <a href="<?php echo e($siteInfo->linkedin_link ?  $siteInfo->linkedin_link : '#'); ?>"><img src="<?php echo e(asset('assets/linkedin.png')); ?>" alt="LinkedIn"></a>
          <a href="<?php echo e($siteInfo->snapchat_link ?  $siteInfo->snapchat_link : '#'); ?>"><img src="<?php echo e(asset('assets/snapchat.png')); ?>" alt="Snapchat"></a>
          <a href="<?php echo e($siteInfo->twitter_link ?  $siteInfo->twitter_link : '#'); ?>"><img src="<?php echo e(asset('assets/twitter.png')); ?>" alt="Twitter"></a>
        </div>
      </div>
    </div>
  
    <div class="footer-bottom">
      <p>جميع الحقوق محفوظة لجامعة الملك فيصل © 2025 | تصميم وتطوير <a class="author" href="https://www.facebook.com/FekraSmartTech/">فكرة سمارت</a></p>
    </div>
  </footer>
  <?php /**PATH C:\laragon\www\kfc_blog\resources\views/components/footer-section.blade.php ENDPATH**/ ?>