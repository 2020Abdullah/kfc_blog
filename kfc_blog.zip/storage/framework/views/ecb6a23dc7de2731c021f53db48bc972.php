

<?php $__env->startSection('page-title'); ?>
المصور التركي التويجرى
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section id="elnawader_post">
    <h3 class="heading_post">
        <a class="link" href="<?php echo e(route('blogView', $blog->id)); ?>">
            <?php echo e($blog->title); ?>

        </a>
        <div class="post_img">
            <img src="<?php echo e(asset($blog->main_image)); ?>" alt="<?php echo e($blog->title); ?>">
        </div>
    </h3>
    <div class="container">
            <div class="elnawader_box">
                <!-- show post -->
                <div class="blog_box">
                    <div class="blog_info">
                        <div class="date">
                            <i aria-hidden="true" class="fas fa-calendar"></i>
                            <span><?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d/m/Y')); ?></span>
                        </div>
                        <div class="comment">
                            <i aria-hidden="true" class="far fa-comment-dots"></i>
                            <span><?php echo e($Allcomment->count()); ?> تعليق</span>
                        </div>
                    </div>
                    <div class="article-content">
                        <div class="container">
                            <?php echo $blog->content; ?>

                        </div>
                    </div>
                </div>

                <!-- show comments post -->
                <div class="comments_box">
                    <div class="container">
                        <div class="comment_total"><?php echo e($Allcomment->count()); ?> تعليق</div>
                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $Allcomment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-12">
                                    <div class="comment-list">
                                        <div class="comment_num"><?php echo e($loop->iteration); ?></div>
                                        <div class="comment_box">
                                            <div class="comment-meta">
                                                <div class="comment_author">يقول <?php echo e($comment->name); ?>:</div>
                                                <div class="comment_date"><?php echo e(\Carbon\Carbon::parse($comment->created_at)->format('d/m/Y \الساعة h:i A')); ?></div>
                                            </div>
                                            <div class="comment_content">
                                                <?php echo e($comment->comment); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <h3>لا يوجد اى تعليقات</h3>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="col-12">
                                <div class="comment_form">
                                    <form action="<?php echo e(route('commentStore')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($blog->id); ?>" name="blog_id">
                                        <div class="mb-2">
                                            <label class="form-label">التعليق</label>
                                            <textarea name="comment_text" class="form-control" id="comment_txt" cols="5" rows="5"></textarea>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label">الإسم</label>
                                            <input name="name" class="form-control" id="comment_txt">
                                        </div>
                                        <button class="btn btn-outline-success">إرسال التعليق</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
</section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elnawader\resources\views/fronted/post.blade.php ENDPATH**/ ?>