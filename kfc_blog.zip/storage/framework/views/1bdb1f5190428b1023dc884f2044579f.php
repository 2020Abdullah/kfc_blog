<?php $__env->startSection('content'); ?>
<div class="bubble"></div>
<div class="bubble"></div>
<div class="bubble"></div>
<div class="auth-wrapper auth-basic px-2">
    <div class="auth-inner my-2">
        <!-- Login basic -->
        <div class="card mb-0">
            <div class="card-body">
                <?php if (isset($component)) { $__componentOriginalb2122d5063402898d1708e1090474179 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2122d5063402898d1708e1090474179 = $attributes; } ?>
<?php $component = App\View\Components\LogoComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LogoComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2122d5063402898d1708e1090474179)): ?>
<?php $attributes = $__attributesOriginalb2122d5063402898d1708e1090474179; ?>
<?php unset($__attributesOriginalb2122d5063402898d1708e1090474179); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2122d5063402898d1708e1090474179)): ?>
<?php $component = $__componentOriginalb2122d5063402898d1708e1090474179; ?>
<?php unset($__componentOriginalb2122d5063402898d1708e1090474179); ?>
<?php endif; ?>
                <form class="auth-login-form mt-2" action="<?php echo e(route('login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-1">
                        <label for="login-email" class="form-label">البريد الإلكتروني</label>
                        <input type="text" class="form-control" id="login-email" name="email" placeholder="AAAA@gmail.com" autofocus />
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger">
                            <p><?php echo e(@$message); ?></p>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="mb-1">
                        <div class="d-flex justify-content-between">
                            <label class="form-label" for="login-password">كلمة السر</label>
                            <a href="#">
                                <small>هل نسيت كلمة السر ؟</small>
                            </a>
                        </div>
                        <div class="input-group input-group-merge form-password-toggle">
                            <input type="password" name="password" class="form-control form-control-merge" id="login-password" name="login-password" tabindex="2" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" aria-describedby="login-password" />
                            <span class="input-group-text cursor-pointer"><i data-feather="eye"></i></span>
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <p><?php echo e(@$message); ?></p>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-1">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="remember-me" tabindex="3" />
                            <label class="form-check-label" for="remember-me">تذكرني</label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success w-100" tabindex="4">تسجيل الدخول</button>
                </form>

                <p class="text-center mt-2">
                    <a href="<?php echo e(route('register')); ?>">
                        <span>إنشاء حساب</span>
                    </a>
                </p>

            </div>
        </div>
        <!-- /Login basic -->
    </div>
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.Auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kfc_blog\resources\views/auth/login.blade.php ENDPATH**/ ?>