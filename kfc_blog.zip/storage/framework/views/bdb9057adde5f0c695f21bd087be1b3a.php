

<?php $__env->startSection('page-title'); ?>
الأخبار
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section id="kfc_allNews page_wrapper_container">
    <div class="heading_wrapper">
        <div class="container">
            <div class="heading_section">
                <h3>الأخبار الرئيسية</h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item" aria-current="page">الرئيسية</li>
                      <li class="breadcrumb-item active">الأخبار الرئيسية</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="container">
        <!-- pages_links -->
        <nav class="pages_links">
            <ul class="nav">
                <?php $__currentLoopData = $Newspages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('pageView', ['id' => $page->id, 'slug' => Str::slug($page->title)])); ?>"><?php echo e($page->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>
        <!-- search box -->
        <div class="serach-box">
            <div class="card">
                <div class="card-body">
                    <h4>البحث</h4>
                    <form action="#">
                        <?php echo csrf_field(); ?>
                        <input type="search" class="form-control search-input" placeholder="عنوان الخبر أو المحتوى">
                        <button type="submit" class="btn btn-primary">بحث</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- show News -->
        <div class="post_allnews_paper">
            <div class="post_news_paper_right">
                <?php $__empty_1 = true; $__currentLoopData = $allNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="card-image">
                                <img src="<?php echo e(asset($news->main_image)); ?>" alt="img">
                            </div>
                            <div class="post_news_paper_content">
                                <a class="post_news_paper_link" href="<?php echo e(route('blogView', ['id' => $news->id, 'slug' => Str::slug($news->title)])); ?>">
                                    <h3 class="post_news_paper_title">
                                        <?php echo e($news->title); ?>

                                    </h3>
                                </a>
                                <p class="post_news_paper_date">
                                    <?php
                                        $date = \Alkoumi\LaravelHijriDate\Hijri::Date('j / m / Y هـ', $news->created_at);
                                    ?>
                                    <i class="fa fa-calendar"></i>
                                    <span>تاريخ النشر: <?php echo e($date); ?></span>
                                </p>
                                <p class="post_news_paper_info">
                                    <?php echo Str::limit($news->content, 250, '...'); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="card">
                        <div class="card-body text-center">
                            <h3>لا توجد اى أخبار حتي الآن</h3>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="page_num">
                    <?php echo e($allNews->links()); ?>

                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kfc_blog\resources\views/fronted/allNews.blade.php ENDPATH**/ ?>