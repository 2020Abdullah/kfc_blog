

<?php $__env->startSection('page-title'); ?>
المصور التركي التويجرى
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section id="elnawader_wedding">
    <div class="container">
            <h3 class="heading_category">
                <a class="link" href="#">
                    <?php echo e($cate_name); ?>

                </a>
            </h3>
            <div class="elnawader_box">
                <div class="row">
                    <?php $__currentLoopData = $getBlogLast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-image">
                                        <a class="link" href="<?php echo e(route('blogView', $blog->id)); ?>">
                                            <img src="<?php echo e(asset($blog->main_image)); ?>" alt="<?php echo e($blog->title); ?>">
                                        </a>
                                    </div>
                                    <div class="card-body">
                                        <a class="link" href="<?php echo e(route('blogView', $blog->id)); ?>">
                                            <h3><?php echo e($blog->title); ?></h3>
                                        </a>
                                    </div>
                                    <div class="card-footer">
                                        <span><?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d/m/Y')); ?></span>
                                    </div>
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
    </div>
</section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elnawader\resources\views/fronted/category.blade.php ENDPATH**/ ?>