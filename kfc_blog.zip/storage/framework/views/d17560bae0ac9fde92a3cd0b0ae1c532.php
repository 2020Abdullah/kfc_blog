

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/dropzone.min.css">
<link
rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"
/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-header'); ?>
<div class="content-header row">
    <div class="content-header-left col-md-9 col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h2 class="content-header-title float-start mb-0">معرض الصور</h2>
                <div class="breadcrumb-wrapper">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">عرض الصور</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="sliderImage">       
        <!-- show slider image -->
        <div class="swiper">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper" id="swiper-wrapper"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>          
        </div>

        <!-- show slider Form -->
        <div class="sliderForm mt-3">
            <div class="card">
                <div class="card-header">
                    <h3>إضافة البوم صور</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('slider.upload')); ?>" class="dropzone" id="dropzone">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($type); ?>" name="sliderType" class="sliderType">
                    </form>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/dropzone.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<script>
let swiper = new Swiper(".swiper", {
    loop: true,
    slidesPerView: 1, // الافتراضي للموبايل
    spaceBetween: 10, // المسافة بين الصور
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    breakpoints: {
        768: { // الأجهزة المتوسطة (التابلت)
            slidesPerView: 2,
            spaceBetween: 20
        },
        1024: { // الأجهزة الكبيرة (الكمبيوتر)
            slidesPerView: 3,
            spaceBetween: 30
        }
    }
});

function fetchImages() {
    $.ajax({
        url: "/slider/fetch",
        type: "GET",
        success: function(data) {
            $('#swiper-wrapper').html(''); // تفريغ السلايدر قبل تحميل الصور الجديدة

            data.forEach(function(image) {
                $('#swiper-wrapper').append(`
                    <div class="swiper-slide">
                        <img src="/uploads/slider/${image.image_path}" alt="Slider Image">
                        <button class="delete-btn" onclick="deleteImage(${image.id})">X</button>
                    </div>
                `);
            });

            swiper.update(); // تحديث السلايدر بعد تحميل الصور الجديدة
        }
    });
}

Dropzone.options.dropzone = {
    maxFilesize: 5,  // الحد الأقصى لحجم الصورة بالميغابايت
    acceptedFiles: "image/*",
    uploadMultiple: true,
    parallelUploads: 10,  // تحميل عدة صور في وقت واحد
    autoProcessQueue: true,
    success: function() {
        fetchImages();
        Swal.fire({
            title: "تمت الإضافة بنجاح!",
            text: "تمت إضافة الصور إلى السلايدر بنجاح 🎉",
            icon: "success",
            showConfirmButton: false,
            timer: 3000  // إغلاق تلقائي بعد 3 ثواني
        });
    }
};

fetchImages();

// delete images

function deleteImage(imageId) {
    Swal.fire({
        title: "هل أنت متأكد؟",
        text: "لن تتمكن من استعادة هذه الصورة!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "نعم، احذفها!",
        cancelButtonText: "إلغاء"
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('/delete-image', {
                method: "POST",
                headers: {
                    "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ id: imageId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire("تم الحذف!", "تم حذف الصورة بنجاح.", "success");
                    location.reload();
                } else {
                    Swal.fire("خطأ!", "حدث خطأ أثناء حذف الصورة.", "error");
                }
            })
            .catch(error => {
                Swal.fire("خطأ!", "حدث خطأ أثناء الاتصال بالخادم.", "error");
                console.error("Error:", error);
            });
        }
    });
}


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kfc_blog\resources\views/dashboard/gellery/slider.blade.php ENDPATH**/ ?>