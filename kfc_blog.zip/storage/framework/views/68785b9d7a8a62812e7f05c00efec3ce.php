

<?php $__env->startSection('page-header'); ?>
<div class="content-header row">
    <div class="content-header-left col-md-9 col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h2 class="content-header-title float-start mb-0">الصفحات</h2>
                <div class="breadcrumb-wrapper">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">الرئيسية</a>
                        </li>
                        <li class="breadcrumb-item"><a href="#">عرض الصفحات</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="content-header-right text-md-end col-md-3 col-12">
        <div class="mb-1 breadcrumb-right">
            <a class="btn btn-primary waves-effect waves-float waves-light" href="<?php echo e(route('page.add')); ?>">إضافة صفحة جديدة</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="pageView">
        <!-- show blog -->
        <div class="page-list-wrapper">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <th>اسم الصفحة</th>
                                <th>الصورة الرئيسية</th>
                                <th>مكان الظهور</th>
                                <th>إجراء</th>
                            </tr>
                            <?php $__empty_1 = true; $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($page->title); ?></td>
                                    <td>
                                        <?php if($page->main_image !== null): ?>
                                            <img class="img_thumb" src="<?php echo e(asset($page->main_image)); ?>" alt="<?php echo e($page->title); ?>">
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($page->location); ?></td>
                                    <td>
                                        <a class="btn btn-primary waves-effect waves-float waves-light" href="<?php echo e(route('page.show', $page->id)); ?>"> 
                                            <i data-feather="eye" class="me-50"></i>
                                            <span>عرض</span>
                                        </a>
                                        <a class="btn btn-success waves-effect waves-float waves-light" href="<?php echo e(route('page.edit', $page->id)); ?>"> 
                                            <i data-feather="edit-2" class="me-50"></i>
                                            <span>تعديل</span>
                                        </a>
                                        <a class="btn btn-danger waves-effect waves-float waves-light delBtn" href="#" data-id="<?php echo e($page->id); ?>" data-bs-toggle="modal" data-bs-target="#DelModel">
                                            <i data-feather="trash" class="me-50"></i>
                                            <span>حذف</span>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="text-center">
                                    <td colspan="5">لا توجد اى صفحات مضافة</td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="page-num">
                        <?php echo e($pages->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- model delete -->
    <?php echo $__env->make('dashboard.page.Mdel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    $(".delBtn").on('click', function(){
        let id = $(this).attr('data-id')
        $("#DelModel .id").val(id);
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\kfc_blog\resources\views/dashboard/page/index.blade.php ENDPATH**/ ?>