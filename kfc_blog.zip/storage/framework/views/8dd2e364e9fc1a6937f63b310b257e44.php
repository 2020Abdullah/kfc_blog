

<?php $__env->startSection('page-header'); ?>
<div class="content-header row">
    <div class="content-header-left col-md-9 col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h2 class="content-header-title float-start mb-0">لوحة التحكم</h2>
                <div class="breadcrumb-wrapper">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">عرض الإحصائيات</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section id="dashboard">       
        <!-- show dashboard -->
        <div class="row">
            <div class="col">
                <div class="card text-center">
                    <div class="card-header">
                        <h3>أقسام الموقع</h3>
                    </div>
                    <div class="card-body">
                        <h3><?php echo e($categoryCount); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-center">
                    <div class="card-header">
                        <h3>المقالات</h3>
                    </div>
                    <div class="card-body">
                        <h3><?php echo e($blogCount); ?></h3>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card text-center">
                    <div class="card-header">
                        <h3>عدد التعليقات</h3>
                    </div>
                    <div class="card-body">
                        <h3><?php echo e($CommentCount); ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- show setting -->
        <div class="card">
            <div class="card-header">
                <h3>إعدادات الموقع</h3>
            </div>
            <form action="<?php echo e(route('update.data')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if($siteInfo == null): ?>
                    <div class="card-body">
                        <ul class="nav nav-tabs" role="tablist">                            
                            <li class="nav-item">
                                <a class="nav-link active" id="site-tab" data-bs-toggle="tab" href="#site" aria-controls="home" role="tab" aria-selected="false">معلومات الموقع</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="social-tab" data-bs-toggle="tab" href="#social" aria-controls="profile" role="tab" aria-selected="true">صفحات التواصل</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-bs-toggle="tab" href="#profile" aria-controls="profile" role="tab" aria-selected="true">ملفك الشخصي</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="site" aria-labelledby="site-tab" role="tabpanel">
                                <div class="mb-2">
                                    <label for="site_name" class="form-label">اسم الموقع</label>
                                    <input type="text" id="site_name" name="site_name" class="form-control">
                                </div>

                                <div class="mb-2">
                                    <label for="site_logo" class="form-label">اللوجو</label>
                                    <input type="file" id="site_logo" name="site_logo" class="form-control">
                                </div>

                                <div class="mb-2">
                                    <label for="site_cover" class="form-label">الغلاف</label>
                                    <input type="file" id="site_cover" name="site_cover" class="form-control">
                                </div>

                                <div class="mb-2">
                                    <label for="welcome_txt" class="form-label">نص ترحيبي</label>
                                    <input type="text" id="welcome_txt" name="welcome_txt" class="form-control">
                                </div>
                            </div>

                            <div class="tab-pane" id="social" aria-labelledby="social-tab" role="tabpanel">
                                <div class="mb-2">
                                    <label for="intagram_link" class="form-label">انستجرام</label>
                                    <input type="text" id="intagram" name="intagram_link" placeholder="https://www.instagram.com/turki_t696/" class="form-control">
                                </div>
                                <div class="mb-2">
                                    <label for="snapchat_link" class="form-label">سناب شات</label>
                                    <input type="text" id="snapchat" name="snapchat_link" placeholder="https://www.snapchat.com/add/turki-t696" class="form-control">
                                </div>
                                <div class="mb-2">
                                    <label for="whatsUp_number" class="form-label">رقم الواتساب</label>
                                    <input type="text" id="whatsUp_number" name="whatsUp_number" placeholder="xxxxxxxxxx" class="form-control">
                                </div>
                            </div>

                            <div class="tab-pane" id="profile" aria-labelledby="profile-tab" role="tabpanel">
                                <div class="mb-2">
                                    <label for="name" class="form-label">اسمك</label>
                                    <input type="text" id="name" name="name" value="<?php echo e(auth()->user()->name); ?>" class="form-control">
                                </div>
                                <div class="mb-2">
                                    <label for="email" class="form-label">بريدك الإلكتروني</label>
                                    <input type="email" id="email" name="email" value="<?php echo e(auth()->user()->email); ?>" class="form-control">
                                </div>
                                <div class="mb-2">
                                    <label for="pass" class="form-label">كلمة السر</label>
                                    <input type="password" id="pass" placeholder="***********" name="pass" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?> 
                    <div class="card-body">
                        <ul class="nav nav-tabs" role="tablist">                            
                            <li class="nav-item">
                                <a class="nav-link active" id="site-tab" data-bs-toggle="tab" href="#site" aria-controls="home" role="tab" aria-selected="false">معلومات الموقع</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="social-tab" data-bs-toggle="tab" href="#social" aria-controls="profile" role="tab" aria-selected="true">صفحات التواصل</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-bs-toggle="tab" href="#profile" aria-controls="profile" role="tab" aria-selected="true">ملفك الشخصي</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="site" aria-labelledby="site-tab" role="tabpanel">
                                <div class="mb-2">
                                    <label for="site_name" class="form-label">اسم الموقع</label>
                                    <input type="text" id="site_name" name="site_name" value="<?php echo e($siteInfo->site_name); ?>" class="form-control">
                                </div>

                                <div class="mb-2">
                                    <label for="site_logo" class="form-label">اللوجو</label>
                                    <input type="file" id="site_logo" name="site_logo" class="form-control">
                                </div>

                                <div class="mb-2">
                                    <label for="site_cover" class="form-label">الغلاف</label>
                                    <input type="file" id="site_cover" name="site_cover" class="form-control">
                                </div>

                                <div class="mb-2">
                                    <label for="welcome_txt" class="form-label">نص ترحيبي</label>
                                    <input type="text" id="welcome_txt" value="<?php echo e($siteInfo->welcome_txt); ?>" name="welcome_txt" class="form-control">
                                </div>
                            </div>

                            <div class="tab-pane" id="social" aria-labelledby="social-tab" role="tabpanel">
                                <div class="mb-2">
                                    <label for="intagram_link" class="form-label">انستجرام</label>
                                    <input type="text" id="intagram" name="intagram_link" value="<?php echo e($siteInfo->intagram_link); ?>" class="form-control">
                                </div>
                                <div class="mb-2">
                                    <label for="snapchat_link" class="form-label">سناب شات</label>
                                    <input type="text" id="snapchat" name="snapchat_link" value="<?php echo e($siteInfo->snapchat_link); ?>" class="form-control">
                                </div>
                                <div class="mb-2">
                                    <label for="whatsUp_number" class="form-label">رقم الواتساب</label>
                                    <input type="text" id="whatsUp_number" name="whatsUp_number" value="<?php echo e($siteInfo->whatsUp_number); ?>"  class="form-control">
                                </div>
                            </div>

                            <div class="tab-pane" id="profile" aria-labelledby="profile-tab" role="tabpanel">
                                <div class="mb-2">
                                    <label for="name" class="form-label">اسمك</label>
                                    <input type="text" id="name" name="name" value="<?php echo e(auth()->user()->name); ?>" class="form-control">
                                </div>
                                <div class="mb-2">
                                    <label for="email" class="form-label">بريدك الإلكتروني</label>
                                    <input type="email" id="email" name="email" value="<?php echo e(auth()->user()->email); ?>" class="form-control">
                                </div>
                                <div class="mb-2">
                                    <label for="pass" class="form-label">كلمة السر</label>
                                    <input type="password" id="pass" placeholder="***********" name="pass" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="card-footer">
                    <button type="submit" class="btn btn-relief-success">حفظ</button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\elnawader\resources\views/dashboard/index.blade.php ENDPATH**/ ?>