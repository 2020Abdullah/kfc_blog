<footer class="elnawader_footer">
    <!-- scrollTop -->
    <div class="scrollTop" id="scrollToTop">
        <i class="fas fa-arrow-alt-circle-up"></i>
    </div>

    <!-- site content -->
    <div class="footer_content" style="background-image: url(<?php echo e(asset('fronted/img/footer_cover.jpg')); ?>)">
        
        <div class="footer_logo">
            <a href="<?php echo e(url('/')); ?>">
                <?php if (isset($component)) { $__componentOriginalb2122d5063402898d1708e1090474179 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2122d5063402898d1708e1090474179 = $attributes; } ?>
<?php $component = App\View\Components\LogoComponent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LogoComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2122d5063402898d1708e1090474179)): ?>
<?php $attributes = $__attributesOriginalb2122d5063402898d1708e1090474179; ?>
<?php unset($__attributesOriginalb2122d5063402898d1708e1090474179); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2122d5063402898d1708e1090474179)): ?>
<?php $component = $__componentOriginalb2122d5063402898d1708e1090474179; ?>
<?php unset($__componentOriginalb2122d5063402898d1708e1090474179); ?>
<?php endif; ?>
            </a>
        </div>

        <div class="footer_contact">
            <!-- social-icons -->
            <div class="social-icons d-flex align-items-center">
                <a href="https://wa.me/<?php echo e($siteInfo->whatsUp_number); ?>"><i class="fab fa-whatsapp"></i></a>
                <a href="<?php echo e($siteInfo->snapchat_link); ?>"><i class="fab fa-snapchat"></i></a>
                <a href="<?php echo e($siteInfo->intagram_link); ?>"><i class="fab fa-instagram"></i></a>
            </div>

            <div class="phone">
                <h3>للحجز: <a href="https://wa.me/<?php echo e($siteInfo->whatsUp_number); ?>" target="_blank" rel="nofollow"><?php echo e($siteInfo->whatsUp_number); ?></a></h3>
            </div>
        </div>
    </div>

    <div class="copyright">
        <p>جميع الحقوق محفوظة لـ المصور تركي التويجري 2025 ®</p>
    </div>

</footer><?php /**PATH C:\laragon\www\elnawader\resources\views/components/footer-section.blade.php ENDPATH**/ ?>