<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SiteInfo extends Model
{
    use HasFactory;

    protected $guarded = [];

    // protected $fillable = ['site_name', 'site_logo', 'site_cover', 'welcome_txt', 'intagram_link', 'snapchat_link', 'whatsUp_number', 'user_id'];

}
